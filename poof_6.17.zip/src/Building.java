import java.awt.*;


public class Building extends Structure
{
	public Building(int x, int y, String imageName, Dimension d)
	{
		super(x, y, imageName, d);
	}
	public Building(int x, Ground g, String iN, Dimension d){
		super(x,g,iN,d);
	}
	public void explode ()
	{

	}
}
