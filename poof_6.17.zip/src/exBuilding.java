import java.awt.Dimension;


public class exBuilding extends Building implements Explodable{

	public exBuilding(int x, Ground g, String iN, Dimension d) {
		super(x, g, iN, d);
		// TODO Auto-generated constructor stub
	}

}
