import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.swing.*;

public class MildlyIrritatedAlpacae extends JApplet implements ActionListener, MouseListener{
	public static final Dimension FRAMESIZE = new Dimension(1200,800);
	Timer t = new Timer(60,this);
	Alpaca ari;
	CopyOnWriteArrayList<Ammo> pellets = new CopyOnWriteArrayList<Ammo>();
	Ground gr;
	ParticleEngine pe;
	CopyOnWriteArrayList<Structure> buildings = new CopyOnWriteArrayList<Structure>();
	JProgressBar powerBar= new JProgressBar(0, 100);
	Grassfro gras;
	int powerR = 255, powerG, powerB = 66;
	int offset;
	enum GameState{playing,won,menu}
	GameState state = GameState.menu;
	public void init(){
		setVisible(true);
		setLayout(null);
		setContentPane(new drawingPanel());
		ari = new Alpaca(3,"Ari.png","Ari Alpaca Mouth.png",this);
		addMouseListener(this);
		gr = new Ground (2, null);
		pe = new ParticleEngine();
		//buildings.add(new Building (850, gr.convertXtoY(850) - 300, "building.jpg", new Dimension (75, 300)));
		//buildings.add(new Building (1000, gr.convertXtoY(1000) - 500, "building.jpg", new Dimension (75, 500)));
		setSize(FRAMESIZE);
		t.start();
		powerBar.setBounds(10, 10, 100, 10);
		add(powerBar);
		for(int i =0; i<15; i++){
			Building b = new Building(300*i+500,gr, "building.png", new Dimension(75,200));
			if(i!=3)buildings.add(b);
			Building b2 = new exBuilding(300*i+700,gr,"building.png", new Dimension(75,300));
			if(i!=2)buildings.add(b2);
		}
		gras = new Grassfro(1300, gr.convertXtoY(1300)-150, "grassfro.gif", new Dimension(150,150));
		buildings.add(gras);
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		for (Particle p : pe.getParticleList())
			p.tick();
		pe.removeOffScreenParticles();
		ari.fluctuatePower();
		powerBar.setValue(ari.getPower());
		changeProgressColor();
		powerBar.setForeground(new Color(powerR, 255 - powerG, powerB));
		if(pellets.size()==0 && pe.getParticleList().size()<=10)	
			if(offset>0)offset/=1.25;
			else offset=0;
		System.out.println(pe.getParticleList().size());
		repaint();
	}
	public class drawingPanel extends JPanel{
		public void paintComponent(Graphics g){
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D)g;	
			setBackground(Color.white);
			g2.setColor(Color.black);
			g2.setStroke(new BasicStroke(1));
			if(state==GameState.playing){
				g2.drawRect((int)ari.getMouseLoc().getX(), (int)ari.getMouseLoc().getY(),10,10);
				for(Ammo a: pellets){
					if(a.getX()>700)offset=a.getX()-700;
					a.draw(g2);
					a.checkCollision(gr);
					for (Structure b: buildings)
						a.checkCollision(b);
					if(a.isDead()){
						if(a.getX()<700)pe.explodeFire(a.getX(),a.getY());
						else pe.explodeFire(700, a.getY());
						pellets.remove(a);
					}
				}
				ari.draw(g2, offset);
				pe.draw(g2,offset);
				g2.setColor(Color.black);
				gr.draw(g2, offset);
				int grassCount=0;
				for (Structure b: buildings){
					b.draw(g2, offset);
					if(b instanceof Grassfro)grassCount++;
					if(b instanceof Explodable && b.removing)buildings.remove(b);
				}
				if(grassCount==0)state=GameState.won;
			}	
			else if(state==GameState.won){
				g2.setFont(new Font("Arial",Font.PLAIN,90));
				g2.drawString("YOU WON!", 300,300);
			}
			if(state==GameState.menu)state=GameState.playing;
		}
	}
	@Override
	public void mouseClicked(MouseEvent arg0) {

	}
	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}
	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}
	@Override
	public void mousePressed(MouseEvent arg0) {
		if(pellets.size()==0 && offset==0)pellets.add(ari.launch());

	}
	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}
	public void changeProgressColor()
	{
		if (ari.getPower() / 100.0 <= 1.0)
			powerG = (int) (255 * (ari.getPower() / 100.0));
	}
}
